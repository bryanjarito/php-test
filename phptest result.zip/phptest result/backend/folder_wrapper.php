<?php

class FolderWrapper {

	private $cms;
	private $folder_list;

	public function __construct($cms) {
		$this->cms = $cms;
		$this->loadAllFolders();
	}

	/**
	 * Loads all folders from DB as a list.
	 *
	 * @return array - list of folders
	 */
	public function loadAllFolders() {
		$db_folders = $this->cms->execute("
			SELECT
				*
			FROM
				`folders`
		");

		$this->folder_list = array();
		foreach ($db_folders as $details) {
			$this->folder_list[$details['id']] = $details;
		}
	}

	/**
	 * Marks folders which have at least $child_num direct subfolders.
	 *
	 * @param int $child_num - minimal number of direct subfolders
	 * @return mixed
	 */
	public function findFolders($child_num=0) {

		// TODO: create a query which will return you the list of folders and number of their direct subfolders, but limit it to only those having more than $child_num subfolders
		$db_folders = $this->cms->execute("SELECT * FROM `folders` f1 WHERE 
    (SELECT count(*) FROM `folders` f2 WHERE f2.id_parent = f1.id_parent) >= $child_num ORDER BY id_parent ASC");
// print_r($db_folders);
		// make folder ID to be the array key
		foreach ($db_folders as $details) {
			$this->folder_list[$details['id']]['highlight'] = true;
		}
    
	}

	/**
	 * Returns the folder tree under given parent folder.
	 *
	 * @param int $folder_id - id of parent folder
	 * @return array - multidimensional array in following format:
	 *
	 * array(
	 *    FOLDER_ID => array ("id"=>FOLDER_ID, "Name"=>FOLDER_NAME, "children"=>array(), "highlight"=>true/false)
	 * )
	 *
	 */
	public function getFolderTree($folder_id=0) {

		// TODO: implement the logic which will return multidimensional array in the format provided above
		$tree = array();
    $this->findFolders($_GET['num']);
    $tree = $this->folder_list;
		return $tree;
	}

}