<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once(__DIR__ . '/../../admin03/loadme.php');
require_once(__DIR__ . '/folder_wrapper.php');

// TODO: use class FolderWrapper to find folders that have at least 4 direct subfolders
// and output json object containing the tree of folders. Number of subfolders should be
// read from the $_GET array (needs to be properly sanitized), if not found, use default value.
$fw = new FolderWrapper($cms);
echo json_encode($fw->getFolderTree(1), JSON_PRETTY_PRINT);
