$(document).ready(function () {
  $('#loadme').click(function () {
    $.get( "http://phptest.com-beta.com/bryanly/backend/data.php?num=4", function( result ) {
      $('#folderlist').html('')
      for (let key in result) {
        $('#folderlist').append('<li>' + result[key].Name + '</li>')
      }
  });
  })
})